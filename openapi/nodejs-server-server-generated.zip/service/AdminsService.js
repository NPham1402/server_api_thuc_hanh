'use strict';


/**
 * adds an inventory item
 * Adds an item to the system
 *
 * inventoryItem InventoryItem Inventory item to add (optional)
 * no response value expected for this operation
 **/
exports.addInventory = function(inventoryItem) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

